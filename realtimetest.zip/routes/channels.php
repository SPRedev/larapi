<?php

use Illuminate\Support\Facades\Broadcast;

/*
|--------------------------------------------------------------------------
| Broadcast Channels
|--------------------------------------------------------------------------
|
| Here you may register all of the event broadcasting channels that your
| application supports. The given channel authorization callbacks are
| used to check if an authenticated user can listen to the channel.
|
*/

Broadcast::channel('App.Models.User.{id}', function ($user, $id) {
    return (int) $user->id === (int) $id;
});

// ✅ ADD THIS CODE BLOCK
// This authorizes users to listen on their own private channel.
Broadcast::channel('user.{userId}', function ($user, $userId) {
    // This ensures that a user can only listen to events sent to their own ID.
    // For example, user with ID 7 can listen to 'user.7', but not 'user.8'.
    return (int) $user->id === (int) $userId;
});
