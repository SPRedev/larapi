<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

// ✅ We implement ShouldBroadcast so Laravel knows to send this to Pusher.
class TaskEvent implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    // --- These are the public properties that will be sent as data ---
    public string $action; // e.g., 'created', 'updated', 'deleted'
    public array $task;    // The task data

    /**
     * Create a new event instance.
     * We will pass the action and the task data when we create the event.
     */
    public function __construct(string $action, array $task)
    {
        $this->action = $action;
        $this->task = $task;
    }

    /**
     * Get the channels the event should broadcast on.
     * This defines WHERE the message is sent.
     * We use a PrivateChannel to ensure only authenticated users can listen.
     * The {userId} part is a placeholder for the actual user's ID.
     */
    public function broadcastOn(): array
    {
        // This is a private channel for a specific user.
        // We will need to authorize this in our routes/channels.php file later.
        return [
            new PrivateChannel('user.' . $this->task['user_id_to_notify']),
        ];
    }

    /**
     * The name of the event as it will be broadcast.
     * This is WHAT the Flutter app will listen for.
     */
    public function broadcastAs(): string
    {
        return 'task-event';
    }
}
