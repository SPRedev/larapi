<?php

namespace App\Providers;

use Illuminate\Support\Facades\Broadcast;
use Illuminate\Support\ServiceProvider;

class BroadcastServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // This line allows Pusher to check for authorization.
        Broadcast::routes();

        // This line explicitly loads your channel authorization rules
        // from the file you created earlier. This is the crucial part.
        require base_path('routes/channels.php');
    }
}
