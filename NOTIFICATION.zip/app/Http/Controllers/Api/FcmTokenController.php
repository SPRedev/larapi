<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FcmTokenController extends Controller
{
    /**
     * Store a new FCM token for the authenticated user.
     * This uses `updateOrCreate` to prevent duplicate tokens.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'token' => 'required|string',
        ]);

        DB::table('fcm_tokens')->updateOrInsert(
            ['token' => $validated['token']], // Find a row with this token
            ['user_id' => $request->user()->id] // Update its user_id or create it
        );

        return response()->json(['message' => 'FCM token stored successfully.'], 200);
    }
}
